import java.util.Scanner;

public class ScannerTest {

    public static void main(String[] arg) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a character");

        char c = scanner.next().charAt(0);
        System.out.println("value = " + c);


    }
}
